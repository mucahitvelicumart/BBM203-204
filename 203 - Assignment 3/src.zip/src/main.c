#include <stdio.h>
#include <stdlib.h>
typedef struct Genes{
    int chromsome;
    struct Genes *next;
}Genes;
typedef struct Population{
    Genes *headgen;
    long  fitness;
    float rank;
    struct Population *next;
}Population;
int power(int sayi){
    int i=1;
    int j=0;
    for (j = 0; j <sayi ; ++j) {
        i=2*i;
    }
    return i;
}
long fitness_eva(Population **head,int length){
    Population *temp=*head;
    Genes *temp2=temp->headgen;
    long i=0;
    int j;
    for ( j= length-1; j >-1 ; --j) {
        i=i+(power(j)*temp2->chromsome);
        temp2=temp2->next;
    }

return i;
}
float rank_eva(Population **head,long worst,long best){
    Population *temp=*head;
    Genes *temp2=temp->headgen;
    float i=0;
    i=(temp->fitness-best)/(worst-best);
    return i;
}
void append(Genes** head_ref, int new_data)
{
    Genes* new_node = (Genes*) malloc(sizeof(Genes));
    Genes* last = *head_ref;
    new_node->chromsome  = new_data;
    new_node->next = NULL;
    if (*head_ref == NULL)
    {
        *head_ref = new_node;
        return;
    }
    while (last->next != NULL){
        last = last->next;
    }
    last->next = new_node;
    return;
}
void append_dna(Population** head_ref, Genes* new_dna)
{
    Population* new_node = (Population*) malloc(sizeof(Population));
    Population* last = *head_ref;
    new_node->headgen  = new_dna;
    new_node->next = NULL;
    if (*head_ref == NULL)
    {
        *head_ref = new_node;
        return;
    }
    while (last->next != NULL){
        last = last->next;
    }

    last->next = new_node;
    return;
}
void display(Genes* node)
{
    Genes* temp=node;
    while (temp != NULL)
    {
        printf("%d", temp->chromsome);
        if (temp->next==NULL){
        }
        else{
            printf(":");
        }
        temp = temp->next;
    }
}
void display_populations(Population **node){
    Population* temp=*node;
    while (temp!=NULL){
        display(temp->headgen);
        printf(" -> %ld",temp->fitness);
        printf("\n");
        temp=temp->next;
    }
}
void findBestChromosome(Population **head,Population *best,int size){
    Population* temp=*head;
    int i;
    while (temp!=NULL){
        if (temp->fitness<best->fitness){
            Genes* temp2=temp->headgen;
            Genes* head_genes=NULL;
            best->fitness=temp->fitness;
            for ( i= 0;i<size ; ++i) {
                append(&head_genes,temp2->chromsome);
                temp2=temp2->next;
            }
            best->headgen=head_genes;
            best->rank=temp->rank;
        }
        temp=temp->next;
    }
}
void findWorstChromosome(Population **head,Population *best,int size){
    Population* temp=*head;
    int i;
    while (temp!=NULL){
        if (temp->fitness>best->fitness){
            Genes* temp2=temp->headgen;
            Genes* head_genes=NULL;
            best->fitness=temp->fitness;
            for ( i= 0;i<size ; ++i) {
                append(&head_genes,temp2->chromsome);
                temp2=temp2->next;
            }
            best->headgen=head_genes;
            best->rank=temp->rank;
        }
        temp=temp->next;
    }
}
void swap(Population *a,Population *b)
{
    Genes* gen=a->headgen;
    a->headgen=b->headgen;
    b->headgen=gen;
    int temp = a->fitness;
    a->fitness = b->fitness;
    b->fitness = temp;
}
void bubbleSort(Population *start)
{
    int swapped;
    Population *ptr1;
    Population *lptr = NULL;
    if (start == NULL)
        return;
    do
    {
        swapped = 0;
        ptr1 = start;
        while (ptr1->next != lptr)
        {
            if (ptr1->fitness > ptr1->next->fitness)
            {
                swap(ptr1, ptr1->next);
                swapped = 1;
            }
            ptr1 = ptr1->next;
        }
        lptr = ptr1;
    }
    while (swapped);
}
void Xover(Population **head, int first,int second,int from,int to){
    Population* temp=*head;
    Population* temp1=*head;
    int i,j,k;
    for (i = 0;i <first-1 ; ++i) {
        temp=temp->next;
    }
    Genes* gecici_gen=temp->headgen;

    for (i = 0; i <from-1 ; ++i) {
        gecici_gen=gecici_gen->next;
    }
    for (i = 0;i <second-1 ; ++i) {
        temp1=temp1->next;
    }
    Genes* gecici_gen2=temp1->headgen;
    for (i = 0;i <from-1 ; ++i) {
        gecici_gen2=gecici_gen2->next;
    }

    for (i = 0;i  <= to-from ; ++i) {
        j=gecici_gen->chromsome;
        gecici_gen->chromsome=gecici_gen2->chromsome;
        gecici_gen2->chromsome=j;
        gecici_gen=gecici_gen->next;
        gecici_gen2=gecici_gen2->next;
    }
}
void Mutate(Population **head, int gen){
    Population* temp=*head;
    int i;
    while (temp!=NULL){
        Genes* gecici=temp->headgen;
        for (i = 0; i <gen-1 ; ++i) {
            gecici=gecici->next;
        }
        if (gecici->chromsome==1){
            gecici->chromsome=0;
        }
        else if (gecici->chromsome==0){
            gecici->chromsome=1;
        }
        temp=temp->next;
    }
}
int main(int argc, char **argv) {
    FILE *fp,*fp1,*fp2,*fp3;
    int i,j,k,s,s1,x,x1,m,PROB_SIZE=atoi(argv[1]),POPULATION_SIZE=atoi(argv[2]),MAX_GEN=atoi(argv[3]);
    fp=fopen("population","r"),fp1=fopen("selection","r"),fp2=fopen("xover","r"),fp3=fopen("mutate","r");
    Population* head_dna=NULL;
    Population* best2=malloc(sizeof(Population));
    Population* worst=malloc(sizeof(Population));
    for ( i = 0; i <POPULATION_SIZE ; ++i) {
        Genes* head_genes=NULL;
        for (k = 0; k <PROB_SIZE ; ++k) {
            fscanf(fp, "%d:", &j);
            append(&head_genes,j);
        }
        append_dna(&head_dna,head_genes);
    }
    Population* temp=head_dna;
    for (i = 0; i <POPULATION_SIZE ; ++i) {
        temp->fitness=fitness_eva(&temp,PROB_SIZE);
        temp=temp->next;
    }
    bubbleSort(head_dna);
    printf("GENERATION: 0\n");
    display_populations(&head_dna);
    best2->fitness=head_dna->fitness;
    best2->rank=head_dna->rank;
    best2->headgen=head_dna->headgen;
    worst->fitness=head_dna->fitness;
    worst->rank=head_dna->rank;
    worst->headgen=head_dna->headgen;
    findBestChromosome(&head_dna,best2,PROB_SIZE);
    findWorstChromosome(&head_dna,worst,PROB_SIZE);
    printf("Best chromosome found so far: ");
    display(best2->headgen);
    printf(" -> %ld\n",best2->fitness);

    for (i = 0; i <MAX_GEN; ++i) {
        fscanf(fp3,"%d",&m);
        fscanf(fp2,"%d:",&x);
        fscanf(fp2,"%d",&x1);
        for (k = 0; k <POPULATION_SIZE/2 ; ++k) {
            fscanf(fp1,"%d:",&s);
            fscanf(fp1,"%d",&s1);
            Xover(&head_dna,s,s1,x,x1);
        }
        Mutate(&head_dna,m);
        temp=head_dna;
        for (k = 0; k <POPULATION_SIZE ; ++k) {
            temp->rank=rank_eva(&temp,worst->fitness,best2->fitness);
            temp->fitness=fitness_eva(&temp,PROB_SIZE);
            temp=temp->next;
        }
        findBestChromosome(&head_dna,best2,PROB_SIZE);
        findWorstChromosome(&head_dna,worst,PROB_SIZE);
        bubbleSort(head_dna);
        printf("GENERATION: %d\n",i+1);
        display_populations(&head_dna);
        printf("Best chromosome found so far: ");
        display(best2->headgen);
        printf(" -> %ld\n",best2->fitness);

    }
    return 0;
}






