#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stddef.h>
#include <time.h>
#include <stdbool.h>
typedef struct{
    bool var;
    char *operator;
}Node;
typedef struct{

    char type[15];
    void *ptr;
}Node1;
typedef struct{
    struct {
        char type1[15];
        char type2[15];
    }Data_type;
    void *ptr1;
    void *ptr2;
}Node2;
typedef struct{
    void *ptr1;
    void *ptr2;
    void *ptr3;
    struct {
        char type1[15];
        char type2[15];
        char type3[15];
    }Data_type;

}Node3;
Node1 *none_child(const char *filename);
Node1 *generate_op(char *type_of,char *filename){
    strcpy(type_of,"node1");
    Node1 *node1=malloc(sizeof(Node1));
    strcpy(node1->type,"node1");
    node1->ptr=none_child(filename);
    return node1;
}
void expression_genarate(void **expression,char *type_of_expression){
    int exp_find=rand()%3;
    if(exp_find==0){
        strcpy(type_of_expression,"<exp-3>");
        Node3 *node3=malloc(sizeof(Node3));
        expression_genarate(&node3->ptr1,node3->Data_type.type1);
        node3->ptr2=generate_op(node3->Data_type.type2,"rel_op");
        expression_genarate(&node3->ptr3,node3->Data_type.type3);
        *expression=node3;
    } else if (exp_find==1){
        strcpy(type_of_expression,"<exp-2>");
        Node2 *node2=malloc(sizeof(Node2));
        node2->ptr1=generate_op(node2->Data_type.type1,"pre_op");
        expression_genarate(&node2->ptr2,node2->Data_type.type2);
        *expression=node2;
    }else{
        *expression=generate_op(type_of_expression,"var");
    }

}
void condition_generate(void **cond,char *type_of_expression){
    int exp_or_con=rand()%2;
    Node3 *condition=malloc(sizeof(Node3));
    strcpy(type_of_expression,"cond");
    if(exp_or_con==0){
        expression_genarate(&condition->ptr1,condition->Data_type.type1);
        condition->ptr2=generate_op(condition->Data_type.type2,"rel_op");
        expression_genarate(&condition->ptr3,condition->Data_type.type3);
    }else{
        condition_generate(&condition->ptr1,condition->Data_type.type1);
        condition->ptr2=generate_op(condition->Data_type.type2,"set_op");
        condition_generate(&condition->ptr3,condition->Data_type.type3);
    }
    *cond=condition;
}
void display_Tree(void *root,char *root_type){
    if(strcmp(root_type,"node")==0){
        Node *node=root;
        if (node->var==true){
            printf("%s",node->operator);
        }
        else{
            printf("%s",node->operator);
        }
    }
    if(strcmp(root_type,"node1")==0){
        Node1 *node1=root;
        display_Tree(node1->ptr,node1->type);
    }
    else if (strcmp(root_type,"<exp-2>")==0){
        Node2 *node2=root;
        display_Tree(node2->ptr1,node2->Data_type.type1);
        printf("(");
        display_Tree(node2->ptr2,node2->Data_type.type2);
        printf(")");
    }
    else if(strcmp(root_type,"<exp-3>")==0) {
        Node3 *node3 = root;
        printf("(");
        display_Tree(node3->ptr1, node3->Data_type.type1);
        printf(")");
        display_Tree(node3->ptr2, node3->Data_type.type2);
        printf("(");
        display_Tree(node3->ptr3, node3->Data_type.type3);
        printf(")");
    }
    else if (strcmp(root_type,"cond")==0){
        Node3 *node3=root;
        printf("(");
        display_Tree(node3->ptr1,node3->Data_type.type1);
        display_Tree(node3->ptr2,node3->Data_type.type2);
        display_Tree(node3->ptr3,node3->Data_type.type3);
        printf(")");
    }
}
int main() {
    srand(time(NULL));
    void *root;
    char type_of_root[15];
    condition_generate(&root,type_of_root);
    printf("if ");
    display_Tree(root,type_of_root);
    printf(" {}\n");
    return 0;
}
/* Returns a random line (w/o newline) from the file provided */
Node1 *none_child(const char *filename) {
    Node1 *node1=malloc(sizeof(Node1));
    strcpy(node1->type,"node");
    Node *node=malloc(sizeof(Node));
    if(strcmp(filename,"var")==0){
        node->var=true;
    }
    int i;
    char output[256],**line;
    line=malloc(sizeof(char*));
    FILE * fp= fopen(filename, "r");
    if (fp == NULL)
        exit(EXIT_FAILURE);

    for (i = 0; fgets(output, sizeof(output),fp)!=NULL ; ++i) {
        line=realloc(line,sizeof(char*)*(i+1));
        line[i]=malloc(sizeof(char)*strlen(output));
        strcpy(line[i],output);
        if(line[i][strlen(line[i])-1]=='\n'){
            line[i][strlen(line[i])-1]='\0';
        }
    }
    int num=rand()%i;
    node->operator=malloc(sizeof(strlen(line[num])));
    strcpy(node->operator,line[num]);
    node1->ptr=node;
    fclose(fp);
    return node1;
}